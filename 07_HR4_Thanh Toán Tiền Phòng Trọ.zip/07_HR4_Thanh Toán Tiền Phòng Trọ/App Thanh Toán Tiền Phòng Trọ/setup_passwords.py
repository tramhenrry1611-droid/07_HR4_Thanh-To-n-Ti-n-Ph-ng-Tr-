"""Băm (hash) mật khẩu trong bảng nguoi_dung. Chạy 1 lần sau khi import db_script.sql.
Cột mat_khau_hash trong file SQL đang chứa mật khẩu dạng chữ thường; script này sẽ mã hóa chúng.
Chạy lại nhiều lần vẫn an toàn (mật khẩu đã mã hóa sẽ được bỏ qua)."""
import os, pymysql
from werkzeug.security import generate_password_hash
c = pymysql.connect(host=os.environ.get("DB_HOST", "localhost"), user=os.environ.get("DB_USER", "root"),
                    password=os.environ.get("DB_PASS", ""), database="quan_ly_phong_tro", charset="utf8mb4", autocommit=True)
with c.cursor() as cur:
    cur.execute("SELECT ma_nguoi_dung, so_dien_thoai, mat_khau_hash FROM nguoi_dung")
    for uid, sdt, mk in cur.fetchall():
        if mk.startswith(("scrypt:", "pbkdf2:")):
            print(sdt, "- đã mã hóa, bỏ qua")
            continue
        cur.execute("UPDATE nguoi_dung SET mat_khau_hash=%s WHERE ma_nguoi_dung=%s", (generate_password_hash(mk), uid))
        print(sdt, "- đã mã hóa mật khẩu")
print("Xong. Đăng nhập bằng số điện thoại và mật khẩu ghi trong db_script.sql.")
