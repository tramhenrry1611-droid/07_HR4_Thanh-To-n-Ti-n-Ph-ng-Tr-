# Phần mềm thanh toán tiền phòng trọ (Flask + MySQL)

## Chạy
1. MySQL Workbench: chạy file `db_script.sql` (tạo CSDL `quan_ly_phong_tro` + dữ liệu mẫu).
2. `pip install -r requirements.txt`
3. (nếu MySQL có mật khẩu) PowerShell: `$env:DB_PASS="mat_khau_mysql"`
4. `python setup_passwords.py`  (mã hóa mật khẩu trong db_script.sql; chạy lại nhiều lần vẫn an toàn)
5. `python app.py` rồi mở http://127.0.0.1:5000

Bảng `thong_bao` (thông báo/nhắc nợ) được app tự tạo ở lần chạy đầu.

## Cấu hình (biến môi trường, đều có mặc định)
- Tài khoản nhận tiền: sửa dòng `BANK = dict(...)` đầu `app.py`.
- `MOMO_SDT` số ví MoMo nhận tiền; `WEBHOOK_SECRET` khóa ký webhook; `DEMO=0` để tắt nút giả lập cổng thanh toán.

## Các kiểu QR
1. VietQR động (số tiền + nội dung HDxx) — quét bằng mọi app ngân hàng/ví hỗ trợ VietQR.
2. QR ví MoMo.  3. QR tĩnh của chủ trọ (ảnh trong static/).
4. QR xác thực biên lai (in trên biên lai, quét ra trang kiểm tra hợp lệ).

## Webhook cổng thanh toán (NFR05)
POST /api/webhooks/payment, header `X-Signature` = HMAC-SHA256(WEBHOOK_SECRET, body thô), body JSON:
{"noi_dung": "CK HD1", "so_tien": 1032500, "ma_giao_dich": "FT123"}  — trùng mã giao dịch sẽ bị bỏ qua.
