-- =====================================================
-- Phần mềm thanh toán tiền phòng trọ - MySQL 8.0
-- =====================================================
DROP DATABASE IF EXISTS quan_ly_phong_tro;
CREATE DATABASE quan_ly_phong_tro CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE quan_ly_phong_tro;

-- 1. Người dùng (chủ trọ & khách thuê)
CREATE TABLE nguoi_dung (
  ma_nguoi_dung  INT AUTO_INCREMENT PRIMARY KEY,
  ho_ten         VARCHAR(100) NOT NULL,
  so_dien_thoai  VARCHAR(15)  NOT NULL UNIQUE,
  email          VARCHAR(100) UNIQUE,
  cccd           VARCHAR(12)  UNIQUE,
  mat_khau_hash  VARCHAR(255) NOT NULL,
  vai_tro        ENUM('CHU_TRO','KHACH_THUE') NOT NULL,
  ngay_tao       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 2. Nhà trọ
CREATE TABLE nha_tro (
  ma_nha_tro   INT AUTO_INCREMENT PRIMARY KEY,
  ma_chu_tro   INT NOT NULL,
  ten_nha_tro  VARCHAR(100) NOT NULL,
  dia_chi      VARCHAR(255) NOT NULL,
  CONSTRAINT fk_nhatro_chutro FOREIGN KEY (ma_chu_tro)
    REFERENCES nguoi_dung(ma_nguoi_dung)
);

-- 3. Phòng
CREATE TABLE phong (
  ma_phong    INT AUTO_INCREMENT PRIMARY KEY,
  ma_nha_tro  INT NOT NULL,
  so_phong    VARCHAR(20) NOT NULL,
  dien_tich   DECIMAL(5,1),
  gia_thue    DECIMAL(12,0) NOT NULL CHECK (gia_thue >= 0),
  trang_thai  ENUM('TRONG','DANG_THUE','BAO_TRI') NOT NULL DEFAULT 'TRONG',
  CONSTRAINT fk_phong_nhatro FOREIGN KEY (ma_nha_tro) REFERENCES nha_tro(ma_nha_tro),
  CONSTRAINT uq_phong UNIQUE (ma_nha_tro, so_phong)
);

-- 4. Hợp đồng thuê
CREATE TABLE hop_dong (
  ma_hop_dong    INT AUTO_INCREMENT PRIMARY KEY,
  ma_phong       INT NOT NULL,
  ma_khach_thue  INT NOT NULL,
  ngay_bat_dau   DATE NOT NULL,
  ngay_ket_thuc  DATE,
  gia_thue       DECIMAL(12,0) NOT NULL CHECK (gia_thue >= 0),
  tien_coc       DECIMAL(12,0) NOT NULL DEFAULT 0,
  ngay_chot      TINYINT NOT NULL DEFAULT 1 CHECK (ngay_chot BETWEEN 1 AND 28),
  trang_thai     ENUM('HIEU_LUC','DA_KET_THUC') NOT NULL DEFAULT 'HIEU_LUC',
  CONSTRAINT fk_hd_phong FOREIGN KEY (ma_phong) REFERENCES phong(ma_phong),
  CONSTRAINT fk_hd_khach FOREIGN KEY (ma_khach_thue) REFERENCES nguoi_dung(ma_nguoi_dung),
  CONSTRAINT ck_hd_ngay CHECK (ngay_ket_thuc IS NULL OR ngay_ket_thuc > ngay_bat_dau)
);

-- 5. Dịch vụ (điện, nước, internet, rác...)
CREATE TABLE dich_vu (
  ma_dich_vu   INT AUTO_INCREMENT PRIMARY KEY,
  ma_nha_tro   INT NOT NULL,
  ten_dich_vu  VARCHAR(50) NOT NULL,
  don_gia      DECIMAL(12,0) NOT NULL CHECK (don_gia >= 0),
  don_vi       VARCHAR(20) NOT NULL,
  cach_tinh    ENUM('THEO_CHI_SO','CO_DINH') NOT NULL,
  CONSTRAINT fk_dv_nhatro FOREIGN KEY (ma_nha_tro) REFERENCES nha_tro(ma_nha_tro),
  CONSTRAINT uq_dv UNIQUE (ma_nha_tro, ten_dich_vu)
);

-- 6. Chỉ số dịch vụ hàng tháng (điện, nước)
CREATE TABLE chi_so_dich_vu (
  ma_chi_so    INT AUTO_INCREMENT PRIMARY KEY,
  ma_hop_dong  INT NOT NULL,
  ma_dich_vu   INT NOT NULL,
  thang        TINYINT NOT NULL CHECK (thang BETWEEN 1 AND 12),
  nam          SMALLINT NOT NULL,
  chi_so_cu    DECIMAL(10,1) NOT NULL,
  chi_so_moi   DECIMAL(10,1) NOT NULL,
  CONSTRAINT fk_cs_hd FOREIGN KEY (ma_hop_dong) REFERENCES hop_dong(ma_hop_dong),
  CONSTRAINT fk_cs_dv FOREIGN KEY (ma_dich_vu) REFERENCES dich_vu(ma_dich_vu),
  CONSTRAINT ck_cs CHECK (chi_so_moi >= chi_so_cu),
  CONSTRAINT uq_cs UNIQUE (ma_hop_dong, ma_dich_vu, thang, nam)
);

-- 7. Hóa đơn tháng
CREATE TABLE hoa_don (
  ma_hoa_don     INT AUTO_INCREMENT PRIMARY KEY,
  ma_hop_dong    INT NOT NULL,
  thang          TINYINT NOT NULL CHECK (thang BETWEEN 1 AND 12),
  nam            SMALLINT NOT NULL,
  han_thanh_toan DATE NOT NULL,
  tong_tien      DECIMAL(12,0) NOT NULL DEFAULT 0,
  trang_thai     ENUM('CHUA_THANH_TOAN','THANH_TOAN_MOT_PHAN','DA_THANH_TOAN','QUA_HAN')
                 NOT NULL DEFAULT 'CHUA_THANH_TOAN',
  ngay_tao       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_hdon_hd FOREIGN KEY (ma_hop_dong) REFERENCES hop_dong(ma_hop_dong),
  CONSTRAINT uq_hdon UNIQUE (ma_hop_dong, thang, nam)
);

-- 8. Chi tiết hóa đơn
CREATE TABLE chi_tiet_hoa_don (
  ma_chi_tiet  INT AUTO_INCREMENT PRIMARY KEY,
  ma_hoa_don   INT NOT NULL,
  ma_dich_vu   INT NULL,                 -- NULL với dòng tiền phòng / phụ thu
  mo_ta        VARCHAR(150) NOT NULL,
  so_luong     DECIMAL(10,1) NOT NULL DEFAULT 1,
  don_gia      DECIMAL(12,0) NOT NULL,
  thanh_tien   DECIMAL(12,0) NOT NULL,
  CONSTRAINT fk_cthd_hdon FOREIGN KEY (ma_hoa_don) REFERENCES hoa_don(ma_hoa_don) ON DELETE CASCADE,
  CONSTRAINT fk_cthd_dv FOREIGN KEY (ma_dich_vu) REFERENCES dich_vu(ma_dich_vu)
);

-- 9. Thanh toán
CREATE TABLE thanh_toan (
  ma_thanh_toan    INT AUTO_INCREMENT PRIMARY KEY,
  ma_hoa_don       INT NOT NULL,
  so_tien          DECIMAL(12,0) NOT NULL CHECK (so_tien > 0),
  phuong_thuc      ENUM('TIEN_MAT','CHUYEN_KHOAN','VI_DIEN_TU') NOT NULL,
  ma_giao_dich     VARCHAR(50),
  ngay_thanh_toan  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  trang_thai       ENUM('THANH_CONG','THAT_BAI','CHO_XAC_NHAN') NOT NULL DEFAULT 'CHO_XAC_NHAN',
  CONSTRAINT fk_tt_hdon FOREIGN KEY (ma_hoa_don) REFERENCES hoa_don(ma_hoa_don)
);

-- Chỉ mục phục vụ truy vấn thường dùng
CREATE INDEX idx_hd_phong      ON hop_dong(ma_phong, trang_thai);
CREATE INDEX idx_hdon_trangthai ON hoa_don(trang_thai, han_thanh_toan);
CREATE INDEX idx_tt_hoadon     ON thanh_toan(ma_hoa_don);

-- View công nợ: số tiền còn phải thu của từng hóa đơn
CREATE VIEW v_cong_no AS
SELECT h.ma_hoa_don, h.ma_hop_dong, h.thang, h.nam, h.han_thanh_toan, h.tong_tien,
       COALESCE(SUM(CASE WHEN t.trang_thai = 'THANH_CONG' THEN t.so_tien END), 0) AS da_thu,
       h.tong_tien - COALESCE(SUM(CASE WHEN t.trang_thai = 'THANH_CONG' THEN t.so_tien END), 0) AS con_no
FROM hoa_don h
LEFT JOIN thanh_toan t ON t.ma_hoa_don = h.ma_hoa_don
GROUP BY h.ma_hoa_don, h.ma_hop_dong, h.thang, h.nam, h.han_thanh_toan, h.tong_tien;

-- =====================================================
-- Dữ liệu mẫu
-- =====================================================
INSERT INTO nguoi_dung (ho_ten, so_dien_thoai, email, cccd, mat_khau_hash, vai_tro) VALUES
('Lê Thị Thùy Trâm', '0934854021', 'tramhenrry1611@gmail.com',   '079200000001', '16112006', 'CHU_TRO'),
('Nguyễn Bích Ngân', '0888040562', 'nguyenbichngan1308@gmail.com', '079200000002', '13082006', 'KHACH_THUE'),
('Lê Tấn Trình', '0369179634', 'letantrinh3@gmail.com','079200000003', '06062006', 'KHACH_THUE');

INSERT INTO nha_tro (ma_chu_tro, ten_nha_tro, dia_chi) VALUES
(1, 'Nhà trọ Haviland', '249/73 Hà Huy Tập, Phường Thanh Khê, TP. Đà Nẵng');

INSERT INTO phong (ma_nha_tro, so_phong, dien_tich, gia_thue, trang_thai) VALUES
(1, 'P101', 20.0, 2500000, 'DANG_THUE'),
(1, 'P102', 22.5, 2800000, 'DANG_THUE'),
(1, 'P103', 18.0, 2200000, 'TRONG');

INSERT INTO hop_dong (ma_phong, ma_khach_thue, ngay_bat_dau, ngay_ket_thuc, gia_thue, tien_coc, ngay_chot) VALUES
(1, 2, '2026-01-01', '2026-12-31', 2500000, 2500000, 5),
(2, 3, '2026-03-01', '2027-02-28', 2800000, 2800000, 5);

INSERT INTO dich_vu (ma_nha_tro, ten_dich_vu, don_gia, don_vi, cach_tinh) VALUES
(1, 'Điện',     3500,   'kWh',   'THEO_CHI_SO'),
(1, 'Nước',     15000,  'm3',    'THEO_CHI_SO'),
(1, 'Internet', 100000, 'tháng', 'CO_DINH'),
(1, 'Rác',      30000,  'tháng', 'CO_DINH');

INSERT INTO chi_so_dich_vu (ma_hop_dong, ma_dich_vu, thang, nam, chi_so_cu, chi_so_moi) VALUES
(1, 1, 9, 2026, 1200.0, 1285.0),
(1, 2, 9, 2026, 85.0,   92.0);

INSERT INTO hoa_don (ma_hop_dong, thang, nam, han_thanh_toan, tong_tien, trang_thai) VALUES
(1, 9, 2026, '2026-10-10', 3032500, 'THANH_TOAN_MOT_PHAN');

INSERT INTO chi_tiet_hoa_don (ma_hoa_don, ma_dich_vu, mo_ta, so_luong, don_gia, thanh_tien) VALUES
(1, NULL, 'Tiền phòng tháng 9/2026', 1,  2500000, 2500000),
(1, 1,    'Điện (1200 → 1285 kWh)', 85, 3500,    297500),
(1, 2,    'Nước (85 → 92 m3)',      7,  15000,   105000),
(1, 3,    'Internet',               1,  100000,  100000),
(1, 4,    'Rác',                    1,  30000,   30000);

INSERT INTO thanh_toan (ma_hoa_don, so_tien, phuong_thuc, ma_giao_dich, trang_thai) VALUES
(1, 2000000, 'CHUYEN_KHOAN', 'FT26091200123', 'THANH_CONG');

-- Kiểm tra công nợ
SELECT * FROM v_cong_no;
