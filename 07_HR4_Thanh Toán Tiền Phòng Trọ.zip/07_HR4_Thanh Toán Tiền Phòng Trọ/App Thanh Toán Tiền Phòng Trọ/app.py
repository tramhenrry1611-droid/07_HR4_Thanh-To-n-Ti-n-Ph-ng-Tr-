import os
from datetime import date, timedelta
from functools import wraps
import pymysql
from flask import Flask, render_template, request, redirect, url_for, session, flash, g, abort
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
BANK = dict(bin="970436", ten="Vietcombank", stk="2934854021", chu="LE THI THUY TRAM")
app.secret_key = os.environ.get("SECRET_KEY", "doi-khoa-bi-mat-nay")
DB = dict(host=os.environ.get("DB_HOST", "localhost"), user=os.environ.get("DB_USER", "root"),
          password=os.environ.get("DB_PASS", ""), database="quan_ly_phong_tro", charset="utf8mb4",
          cursorclass=pymysql.cursors.DictCursor, autocommit=True)


def db():
    if "db" not in g:
        g.db = pymysql.connect(**DB)
    return g.db


@app.teardown_appcontext
def close_db(_):
    c = g.pop("db", None)
    if c:
        c.close()


def q(sql, a=(), one=False):
    with db().cursor() as c:
        c.execute(sql, a)
        return c.fetchone() if one else c.fetchall()


def ex(sql, a=()):
    with db().cursor() as c:
        c.execute(sql, a)
        return c.lastrowid


def run(sql, a, ok):
    try:
        ex(sql, a)
        flash(ok)
    except pymysql.MySQLError as e:
        flash("Lỗi: " + str(e.args[-1]))


@app.template_filter("vnd")
def vnd(v):
    return f"{int(v or 0):,}".replace(",", ".") + " đ"


def login_required(role=None):
    def deco(f):
        @wraps(f)
        def w(*a, **k):
            if "uid" not in session:
                return redirect(url_for("login"))
            if role and session["role"] != role:
                flash("Bạn không có quyền truy cập trang này.")
                return redirect(url_for("index"))
            return f(*a, **k)
        return w
    return deco


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        sdt = request.form["sdt"].strip()
        dem, den = LOCK.get(sdt, (0, 0))
        if den > time.time():
            flash(f"Tài khoản bị khóa tạm thời, thử lại sau {int((den - time.time()) // 60) + 1} phút.")
            return render_template("login.html")
        u = q("SELECT * FROM nguoi_dung WHERE so_dien_thoai=%s", (sdt,), True)
        if u and check_password_hash(u["mat_khau_hash"], request.form["mk"]):
            LOCK.pop(sdt, None)
            session.update(uid=u["ma_nguoi_dung"], role=u["vai_tro"], name=u["ho_ten"])
            return redirect(url_for("index"))
        dem += 1
        LOCK[sdt] = (0 if dem >= 5 else dem, time.time() + 900 if dem >= 5 else 0)
        flash("Sai quá 5 lần, khóa 15 phút." if dem >= 5 else f"Sai số điện thoại hoặc mật khẩu ({dem}/5).")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/")
@login_required()
def index():
    if session["role"] != "CHU_TRO":
        return khach_home()
    uid, t = session["uid"], date.today()
    cnt = {r["trang_thai"]: r["c"] for r in q("SELECT p.trang_thai, COUNT(*) c FROM phong p JOIN nha_tro n ON n.ma_nha_tro=p.ma_nha_tro "
                                              "WHERE n.ma_chu_tro=%s GROUP BY p.trang_thai", (uid,))}
    thu = q("SELECT COALESCE(SUM(t.so_tien),0) s FROM thanh_toan t JOIN hoa_don v ON v.ma_hoa_don=t.ma_hoa_don "
            "JOIN hop_dong h ON h.ma_hop_dong=v.ma_hop_dong JOIN phong p ON p.ma_phong=h.ma_phong "
            "JOIN nha_tro n ON n.ma_nha_tro=p.ma_nha_tro WHERE n.ma_chu_tro=%s AND t.trang_thai='THANH_CONG' "
            "AND YEAR(t.ngay_thanh_toan)=%s AND MONTH(t.ngay_thanh_toan)=%s", (uid, t.year, t.month), True)["s"]
    no = q(INV + scope() + " AND v.con_no>0 ORDER BY v.han_thanh_toan", (uid,))
    cho = q("SELECT t.*, v.thang, v.nam, p.so_phong, u.ho_ten FROM thanh_toan t JOIN hoa_don v ON v.ma_hoa_don=t.ma_hoa_don "
            "JOIN hop_dong h ON h.ma_hop_dong=v.ma_hop_dong JOIN phong p ON p.ma_phong=h.ma_phong "
            "JOIN nha_tro n ON n.ma_nha_tro=p.ma_nha_tro JOIN nguoi_dung u ON u.ma_nguoi_dung=h.ma_khach_thue "
            "WHERE n.ma_chu_tro=%s AND t.trang_thai='CHO_XAC_NHAN' ORDER BY t.ngay_thanh_toan", (uid,))
    return render_template("index.html", cho=cho, cnt=cnt, tong_phong=sum(cnt.values()), thu=thu,
                           tong_no=sum(r["con_no"] for r in no), qua_han=[r for r in no if r["han_thanh_toan"] < t])


@app.route("/khach-thue", methods=["GET", "POST"])
@login_required("CHU_TRO")
def khach_thue():
    if request.method == "POST":
        f = request.form
        run("INSERT INTO nguoi_dung (ho_ten, so_dien_thoai, email, cccd, mat_khau_hash, vai_tro) VALUES (%s,%s,%s,%s,%s,'KHACH_THUE')",
            (f["ho_ten"], f["sdt"], f["email"] or None, f["cccd"] or None, generate_password_hash(f["mk"])), "Đã thêm khách thuê.")
        return redirect(url_for("khach_thue"))
    rows = q("SELECT u.*, (SELECT GROUP_CONCAT(p.so_phong) FROM hop_dong h JOIN phong p ON p.ma_phong=h.ma_phong "
             "WHERE h.ma_khach_thue=u.ma_nguoi_dung AND h.trang_thai='HIEU_LUC') AS phong FROM nguoi_dung u WHERE u.vai_tro='KHACH_THUE'")
    form = [("ho_ten", "Họ tên", "text", None), ("sdt", "Số điện thoại", "text", None), ("cccd", "CCCD", "text", None),
            ("email", "Email", "email", None), ("mk", "Mật khẩu", "password", None)]
    cols = [("ho_ten", "Họ tên", ""), ("so_dien_thoai", "SĐT", ""), ("cccd", "CCCD", ""), ("email", "Email", ""), ("phong", "Đang thuê", "")]
    return render_template("page.html", title="Khách thuê", form=form, cols=cols, rows=rows)


@app.post("/phong/<int:id>/xoa")
@login_required("CHU_TRO")
def xoa_phong(id):
    run("DELETE p FROM phong p JOIN nha_tro n ON n.ma_nha_tro=p.ma_nha_tro WHERE p.ma_phong=%s AND n.ma_chu_tro=%s AND p.trang_thai='TRONG'",
        (id, session["uid"]), "Đã xóa phòng (nếu phòng chưa có hợp đồng).")
    return redirect(url_for("phong"))


@app.post("/hop-dong/<int:id>/thanh-ly")
@login_required("CHU_TRO")
def thanh_ly(id):
    h = q("SELECT h.* FROM hop_dong h " + "JOIN phong p ON p.ma_phong=h.ma_phong JOIN nha_tro n ON n.ma_nha_tro=p.ma_nha_tro " + "WHERE h.ma_hop_dong=%s AND n.ma_chu_tro=%s AND h.trang_thai='HIEU_LUC'",
          (id, session["uid"]), True)
    if not h:
        abort(404)
    no = q("SELECT COALESCE(SUM(con_no),0) s FROM v_cong_no WHERE ma_hop_dong=%s", (id,), True)["s"]
    ex("UPDATE hop_dong SET trang_thai='DA_KET_THUC' WHERE ma_hop_dong=%s", (id,))
    ex("UPDATE phong SET trang_thai='TRONG' WHERE ma_phong=%s", (h["ma_phong"],))
    flash(f"Đã thanh lý hợp đồng. Tiền cọc {vnd(h['tien_coc'])}, còn nợ {vnd(no)} → hoàn lại khách {vnd(max(h['tien_coc'] - no, 0))}"
          + (f", khách còn phải đóng thêm {vnd(no - h['tien_coc'])}." if no > h["tien_coc"] else "."))
    return redirect(url_for("hop_dong"))


@app.route("/dich-vu", methods=["GET", "POST"])
@login_required("CHU_TRO")
def dich_vu():
    uid = session["uid"]
    if request.method == "POST":
        f = request.form
        run("INSERT INTO dich_vu (ma_nha_tro, ten_dich_vu, don_gia, don_vi, cach_tinh) SELECT ma_nha_tro,%s,%s,%s,%s FROM nha_tro "
            "WHERE ma_nha_tro=%s AND ma_chu_tro=%s", (f["ten"], f["gia"], f["dv"], f["ct"], f["nt"], uid), "Đã thêm dịch vụ.")
        return redirect(url_for("dich_vu"))
    nt = q("SELECT ma_nha_tro, ten_nha_tro FROM nha_tro WHERE ma_chu_tro=%s", (uid,))
    rows = q("SELECT d.* FROM dich_vu d JOIN nha_tro n ON n.ma_nha_tro=d.ma_nha_tro WHERE n.ma_chu_tro=%s ORDER BY d.ma_dich_vu", (uid,))
    return render_template("dichvu.html", nt=nt, rows=rows)


@app.post("/dich-vu/<int:id>/gia")
@login_required("CHU_TRO")
def dv_gia(id):
    run("UPDATE dich_vu d JOIN nha_tro n ON n.ma_nha_tro=d.ma_nha_tro SET d.don_gia=%s WHERE d.ma_dich_vu=%s AND n.ma_chu_tro=%s",
        (request.form["gia"], id, session["uid"]), "Đã cập nhật đơn giá (hóa đơn cũ không đổi).")
    return redirect(url_for("dich_vu"))


@app.post("/dich-vu/<int:id>/xoa")
@login_required("CHU_TRO")
def dv_xoa(id):
    run("DELETE d FROM dich_vu d JOIN nha_tro n ON n.ma_nha_tro=d.ma_nha_tro WHERE d.ma_dich_vu=%s AND n.ma_chu_tro=%s",
        (id, session["uid"]), "Đã xóa dịch vụ.")
    return redirect(url_for("dich_vu"))


# ---------- PHÒNG ----------
@app.route("/phong", methods=["GET", "POST"])
@login_required("CHU_TRO")
def phong():
    uid = session["uid"]
    if request.method == "POST":
        f = request.form
        run("INSERT INTO phong (ma_nha_tro, so_phong, dien_tich, gia_thue) "
            "SELECT ma_nha_tro, %s, %s, %s FROM nha_tro WHERE ma_nha_tro=%s AND ma_chu_tro=%s",
            (f["so_phong"], f["dien_tich"] or None, f["gia_thue"], f["ma_nha_tro"], uid), "Đã thêm phòng.")
        return redirect(url_for("phong"))
    nt = q("SELECT ma_nha_tro, ten_nha_tro FROM nha_tro WHERE ma_chu_tro=%s", (uid,))
    rows = q("SELECT p.*, n.ten_nha_tro FROM phong p JOIN nha_tro n ON n.ma_nha_tro=p.ma_nha_tro "
             "WHERE n.ma_chu_tro=%s ORDER BY n.ma_nha_tro, p.so_phong", (uid,))
    form = [("ma_nha_tro", "Nhà trọ", "select", [(x["ma_nha_tro"], x["ten_nha_tro"]) for x in nt]),
            ("so_phong", "Số phòng", "text", None), ("dien_tich", "Diện tích (m²)", "number", None),
            ("gia_thue", "Giá thuê", "number", None)]
    cols = [("ten_nha_tro", "Nhà trọ", ""), ("so_phong", "Phòng", ""), ("dien_tich", "m²", ""),
            ("gia_thue", "Giá thuê", "m"), ("trang_thai", "Trạng thái", "")]
    return render_template("page.html", title="Quản lý phòng", form=form, cols=cols, rows=rows,
                           act=("xoa_phong", "ma_phong", "Xóa", "TRONG"), link=("sua_phong", "ma_phong", "Sửa", "id"))


# ---------- HỢP ĐỒNG ----------
@app.route("/hop-dong", methods=["GET", "POST"])
@login_required("CHU_TRO")
def hop_dong():
    uid = session["uid"]
    if request.method == "POST":
        f = request.form
        try:
            hid = ex("INSERT INTO hop_dong (ma_phong, ma_khach_thue, ngay_bat_dau, ngay_ket_thuc, gia_thue, tien_coc, ngay_chot) "
                     "SELECT p.ma_phong, %s, %s, %s, p.gia_thue, %s, %s FROM phong p "
                     "JOIN nha_tro n ON n.ma_nha_tro=p.ma_nha_tro "
                     "WHERE p.ma_phong=%s AND n.ma_chu_tro=%s AND p.trang_thai='TRONG'",
                     (f["ma_khach_thue"], f["bd"], f["kt"] or None, f["coc"] or 0, f["chot"], f["ma_phong"], uid))
            if hid:
                ex("UPDATE phong SET trang_thai='DANG_THUE' WHERE ma_phong=%s", (f["ma_phong"],))
                flash("Đã tạo hợp đồng.")
            else:
                flash("Phòng không còn trống hoặc không thuộc nhà trọ của bạn.")
        except pymysql.MySQLError as e:
            flash("Lỗi: " + str(e.args[-1]))
        return redirect(url_for("hop_dong"))
    rooms = q("SELECT p.ma_phong, p.so_phong FROM phong p JOIN nha_tro n ON n.ma_nha_tro=p.ma_nha_tro "
              "WHERE n.ma_chu_tro=%s AND p.trang_thai='TRONG'", (uid,))
    ks = q("SELECT ma_nguoi_dung, ho_ten FROM nguoi_dung WHERE vai_tro='KHACH_THUE'")
    rows = q("SELECT h.*, p.so_phong, u.ho_ten FROM hop_dong h JOIN phong p ON p.ma_phong=h.ma_phong "
             "JOIN nha_tro n ON n.ma_nha_tro=p.ma_nha_tro JOIN nguoi_dung u ON u.ma_nguoi_dung=h.ma_khach_thue "
             "WHERE n.ma_chu_tro=%s ORDER BY h.ma_hop_dong DESC", (uid,))
    form = [("ma_phong", "Phòng trống", "select", [(r["ma_phong"], r["so_phong"]) for r in rooms]),
            ("ma_khach_thue", "Khách thuê", "select", [(k["ma_nguoi_dung"], k["ho_ten"]) for k in ks]),
            ("bd", "Ngày bắt đầu", "date", None), ("kt", "Ngày kết thúc", "date", None),
            ("coc", "Tiền cọc", "number", None), ("chot", "Ngày chốt (1-28)", "number", None)]
    cols = [("so_phong", "Phòng", ""), ("ho_ten", "Khách thuê", ""), ("ngay_bat_dau", "Từ", ""),
            ("ngay_ket_thuc", "Đến", ""), ("gia_thue", "Giá thuê", "m"), ("tien_coc", "Tiền cọc", "m"),
            ("trang_thai", "Trạng thái", "")]
    return render_template("page.html", title="Hợp đồng thuê", form=form, cols=cols, rows=rows,
                           act=("thanh_ly", "ma_hop_dong", "Thanh lý", "HIEU_LUC"))


# ---------- CHỈ SỐ ĐIỆN NƯỚC ----------
@app.route("/chi-so", methods=["GET", "POST"])
@login_required("CHU_TRO")
def chi_so():
    uid = session["uid"]
    if request.method == "POST":
        f = request.form
        ok = q("SELECT 1 AS x FROM hop_dong h JOIN phong p ON p.ma_phong=h.ma_phong "
               "JOIN nha_tro n ON n.ma_nha_tro=p.ma_nha_tro JOIN dich_vu d ON d.ma_nha_tro=n.ma_nha_tro "
               "WHERE h.ma_hop_dong=%s AND d.ma_dich_vu=%s AND n.ma_chu_tro=%s",
               (f["hd"], f["dv"], uid), True)
        if not ok:
            abort(403)
        t, n = int(f["thang"]), int(f["nam"])
        prev = q("SELECT chi_so_moi FROM chi_so_dich_vu WHERE ma_hop_dong=%s AND ma_dich_vu=%s "
                 "AND (nam < %s OR (nam=%s AND thang < %s)) ORDER BY nam DESC, thang DESC LIMIT 1",
                 (f["hd"], f["dv"], n, n, t), True)
        cu = prev["chi_so_moi"] if prev else 0
        run("INSERT INTO chi_so_dich_vu (ma_hop_dong, ma_dich_vu, thang, nam, chi_so_cu, chi_so_moi) "
            "VALUES (%s,%s,%s,%s,%s,%s) ON DUPLICATE KEY UPDATE chi_so_moi=VALUES(chi_so_moi)",
            (f["hd"], f["dv"], t, n, cu, f["moi"]), "Đã lưu chỉ số.")
        return redirect(url_for("chi_so"))
    hds = q("SELECT h.ma_hop_dong, p.so_phong, u.ho_ten FROM hop_dong h JOIN phong p ON p.ma_phong=h.ma_phong "
            "JOIN nha_tro n ON n.ma_nha_tro=p.ma_nha_tro JOIN nguoi_dung u ON u.ma_nguoi_dung=h.ma_khach_thue "
            "WHERE n.ma_chu_tro=%s AND h.trang_thai='HIEU_LUC'", (uid,))
    dvs = q("SELECT d.ma_dich_vu, d.ten_dich_vu FROM dich_vu d JOIN nha_tro n ON n.ma_nha_tro=d.ma_nha_tro "
            "WHERE n.ma_chu_tro=%s AND d.cach_tinh='THEO_CHI_SO'", (uid,))
    rows = q("SELECT c.*, d.ten_dich_vu, p.so_phong FROM chi_so_dich_vu c "
             "JOIN dich_vu d ON d.ma_dich_vu=c.ma_dich_vu JOIN hop_dong h ON h.ma_hop_dong=c.ma_hop_dong "
             "JOIN phong p ON p.ma_phong=h.ma_phong JOIN nha_tro n ON n.ma_nha_tro=p.ma_nha_tro "
             "WHERE n.ma_chu_tro=%s ORDER BY c.nam DESC, c.thang DESC, p.so_phong", (uid,))
    today = date.today()
    form = [("hd", "Phòng / khách", "select", [(h["ma_hop_dong"], f'{h["so_phong"]} - {h["ho_ten"]}') for h in hds]),
            ("dv", "Dịch vụ", "select", [(d["ma_dich_vu"], d["ten_dich_vu"]) for d in dvs]),
            ("thang", "Tháng", "number", today.month), ("nam", "Năm", "number", today.year),
            ("moi", "Chỉ số mới", "number", None)]
    cols = [("so_phong", "Phòng", ""), ("ten_dich_vu", "Dịch vụ", ""), ("thang", "Tháng", ""), ("nam", "Năm", ""),
            ("chi_so_cu", "Chỉ số cũ", ""), ("chi_so_moi", "Chỉ số mới", "")]
    return render_template("page.html", title="Chỉ số điện, nước", form=form, cols=cols, rows=rows)


# ---------- HÓA ĐƠN ----------
INV = ("SELECT v.*, p.so_phong, u.ho_ten, CASE WHEN v.con_no<=0 THEN 'Đã thanh toán' "
       "WHEN v.han_thanh_toan < CURDATE() THEN 'Quá hạn' WHEN v.da_thu>0 THEN 'Thanh toán một phần' "
       "ELSE 'Chưa thanh toán' END AS tt FROM v_cong_no v JOIN hop_dong h ON h.ma_hop_dong=v.ma_hop_dong "
       "JOIN phong p ON p.ma_phong=h.ma_phong JOIN nha_tro n ON n.ma_nha_tro=p.ma_nha_tro "
       "JOIN nguoi_dung u ON u.ma_nguoi_dung=h.ma_khach_thue ")


def scope():
    return ("WHERE n.ma_chu_tro=%s" if session["role"] == "CHU_TRO" else "WHERE h.ma_khach_thue=%s")


@app.route("/hoa-don")
@login_required()
def hoa_don():
    no = request.args.get("no")
    ar, ex_w = request.args, ""
    par = [session["uid"]]
    for k, col in (("thang", "v.thang"), ("nam", "v.nam"), ("nt", "n.ma_nha_tro")):
        if ar.get(k):
            ex_w += f" AND {col}=%s"
            par.append(int(ar[k]))
    ex_w += {"chua": " AND v.da_thu=0 AND v.con_no>0 AND v.han_thanh_toan>=CURDATE()", "mot_phan": " AND v.da_thu>0 AND v.con_no>0",
             "qua_han": " AND v.con_no>0 AND v.han_thanh_toan<CURDATE()", "da": " AND v.con_no<=0"}.get(ar.get("tt"), "")
    rows = q(INV + scope() + (" AND v.con_no>0" if no else "") + ex_w + " ORDER BY v.nam DESC, v.thang DESC, p.so_phong", tuple(par))
    nts = q("SELECT ma_nha_tro, ten_nha_tro FROM nha_tro WHERE ma_chu_tro=%s", (session["uid"],)) if session["role"] == "CHU_TRO" else []
    cols = [("so_phong", "Phòng", ""), ("ho_ten", "Khách thuê", ""), ("thang", "Tháng", ""), ("nam", "Năm", ""),
            ("tong_tien", "Tổng tiền", "m"), ("da_thu", "Đã thu", "m"), ("con_no", "Còn nợ", "m"),
            ("han_thanh_toan", "Hạn", ""), ("tt", "Tình trạng", "")]
    form, action = None, None
    if session["role"] == "CHU_TRO":
        t = date.today()
        form = [("thang", "Tháng", "number", t.month), ("nam", "Năm", "number", t.year)]
        action = url_for("tao_hoa_don")
    return render_template("page.html", title="Công nợ" if no else "Hóa đơn", form=form, form_action=action,
                           submit="Tạo hóa đơn tháng", cols=cols, rows=rows, detail=True,
                           filt=dict(nts=nts, ar=ar))


def sync_status(hid):
    r = q("SELECT tong_tien, da_thu FROM v_cong_no WHERE ma_hoa_don=%s", (hid,), True)
    st = "DA_THANH_TOAN" if r["da_thu"] >= r["tong_tien"] else ("THANH_TOAN_MOT_PHAN" if r["da_thu"] > 0 else "CHUA_THANH_TOAN")
    ex("UPDATE hoa_don SET trang_thai=%s WHERE ma_hoa_don=%s", (st, hid))


@app.post("/thanh-toan/<int:id>/<act>")
@login_required("CHU_TRO")
def duyet(id, act):
    if act not in ("xac-nhan", "tu-choi"):
        abort(404)
    r = q("SELECT t.ma_hoa_don FROM thanh_toan t JOIN hoa_don v ON v.ma_hoa_don=t.ma_hoa_don "
          "JOIN hop_dong h ON h.ma_hop_dong=v.ma_hop_dong JOIN phong p ON p.ma_phong=h.ma_phong "
          "JOIN nha_tro n ON n.ma_nha_tro=p.ma_nha_tro "
          "WHERE t.ma_thanh_toan=%s AND n.ma_chu_tro=%s AND t.trang_thai='CHO_XAC_NHAN'", (id, session["uid"]), True)
    if not r:
        abort(404)
    ex("UPDATE thanh_toan SET trang_thai=%s WHERE ma_thanh_toan=%s", ("THANH_CONG" if act == "xac-nhan" else "THAT_BAI", id))
    sync_status(r["ma_hoa_don"])
    flash("Đã xác nhận khoản thanh toán." if act == "xac-nhan" else "Đã từ chối khoản thanh toán.")
    return redirect(url_for("chi_tiet", hid=r["ma_hoa_don"]))


@app.route("/hoa-don/<int:hid>", methods=["GET", "POST"])
@login_required()
def chi_tiet(hid):
    inv = q(INV + scope() + " AND v.ma_hoa_don=%s", (session["uid"], hid), True)
    if not inv:
        abort(404)
    if request.method == "POST":
        f = request.form
        sotien = int(f["so_tien"])
        if sotien <= 0 or sotien > inv["con_no"]:
            flash("Số tiền phải lớn hơn 0 và không vượt quá số còn nợ.")
        elif session["role"] == "CHU_TRO":
            ex("INSERT INTO thanh_toan (ma_hoa_don, so_tien, phuong_thuc, ma_giao_dich, trang_thai) "
               "VALUES (%s,%s,%s,%s,'THANH_CONG')", (hid, sotien, f["phuong_thuc"], f["ma_gd"] or None))
            sync_status(hid)
            flash("Đã ghi nhận thanh toán.")
        else:
            ex("INSERT INTO thanh_toan (ma_hoa_don, so_tien, phuong_thuc, ma_giao_dich, trang_thai) "
               "VALUES (%s,%s,'CHUYEN_KHOAN',%s,'CHO_XAC_NHAN')", (hid, sotien, f["ma_gd"] or None))
            flash("Đã gửi thông báo thanh toán. Chủ trọ sẽ đối chiếu và xác nhận.")
        return redirect(url_for("chi_tiet", hid=hid))
    lines = q("SELECT * FROM chi_tiet_hoa_don WHERE ma_hoa_don=%s", (hid,))
    pays = q("SELECT * FROM thanh_toan WHERE ma_hoa_don=%s ORDER BY ngay_thanh_toan", (hid,))
    return render_template("invoice.html", inv=inv, lines=lines, pays=pays, bank=BANK, demo=DEMO,
                           vq=vietqr(BANK["bin"], BANK["stk"], int(inv["con_no"]), f"HD{hid}"),
                           momo=f"https://nhantien.momo.vn/{BANK['momo']}/{int(inv['con_no'])}")


# ======================= BỔ SUNG THEO BÁO CÁO =======================
import hmac, hashlib, re, csv, io, time
from markupsafe import Markup
from urllib.parse import quote
from flask import Response
try:
    import segno
except ImportError:
    segno = None

BANK["momo"] = os.environ.get("MOMO_SDT", "0934854021")
SECRET = os.environ.get("WEBHOOK_SECRET", "doi-secret-webhook")
DEMO = os.environ.get("DEMO", "1") == "1"
LOCK = {}
_ready = [False]


@app.before_request
def _init_tables():
    if not _ready[0]:
        ex("CREATE TABLE IF NOT EXISTS thong_bao (ma_thong_bao INT AUTO_INCREMENT PRIMARY KEY, ma_nguoi_nhan INT NOT NULL, "
           "noi_dung VARCHAR(255) NOT NULL, ma_hoa_don INT NULL, da_doc TINYINT NOT NULL DEFAULT 0, "
           "ngay_tao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (ma_nguoi_nhan) REFERENCES nguoi_dung(ma_nguoi_dung))")
        _ready[0] = True


def notify(uid, text, hid=None):
    ex("INSERT INTO thong_bao (ma_nguoi_nhan, noi_dung, ma_hoa_don) VALUES (%s,%s,%s)", (uid, text, hid))


@app.context_processor
def _unread():
    if "uid" in session and _ready[0]:
        return {"unread": q("SELECT COUNT(*) c FROM thong_bao WHERE ma_nguoi_nhan=%s AND da_doc=0", (session["uid"],), True)["c"]}
    return {"unread": 0}


# ---------- QR ----------
def _tlv(i, v):
    return f"{i}{len(v):02d}{v}"


def _crc16(s):
    crc = 0xFFFF
    for b in s.encode():
        crc ^= b << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) & 0xFFFF if crc & 0x8000 else (crc << 1) & 0xFFFF
    return f"{crc:04X}"


def vietqr(bin_, stk, amount=None, content=""):
    """Chuỗi VietQR chuẩn NAPAS/EMVCo; mọi app ngân hàng và ví hỗ trợ VietQR đều quét được."""
    acc = _tlv("00", "A000000727") + _tlv("01", _tlv("00", bin_) + _tlv("01", stk)) + _tlv("02", "QRIBFTTA")
    p = (_tlv("00", "01") + _tlv("01", "12" if amount else "11") + _tlv("38", acc) + _tlv("53", "704")
         + (_tlv("54", str(int(amount))) if amount else "") + _tlv("58", "VN")
         + (_tlv("62", _tlv("08", content)) if content else "") + "6304")
    return p + _crc16(p)


@app.template_global()
def qr(data, size=230):
    if segno:
        return Markup(f'<div class="qrbox" style="width:{size}px">{segno.make(data, error="m").svg_inline(scale=4, border=2)}</div>')
    return Markup(f'<img width="{size}" alt="QR" src="https://api.qrserver.com/v1/create-qr-code/?size={size}x{size}&data={quote(data)}">')


def ky(pid):
    return hmac.new(SECRET.encode(), f"BL{pid}".encode(), hashlib.sha256).hexdigest()[:16]


# ---------- ĐĂNG KÝ / KHÓA ĐĂNG NHẬP ----------
@app.route("/dang-ky", methods=["GET", "POST"])
def dang_ky():
    if request.method == "POST":
        f = request.form
        if len(f["mk"]) < 6:
            flash("Mật khẩu tối thiểu 6 ký tự.")
        else:
            try:
                ex("INSERT INTO nguoi_dung (ho_ten, so_dien_thoai, mat_khau_hash, vai_tro) VALUES (%s,%s,%s,%s)",
                   (f["ho_ten"], f["sdt"].strip(), generate_password_hash(f["mk"]), "CHU_TRO" if f["vai_tro"] == "CHU_TRO" else "KHACH_THUE"))
                flash("Đăng ký thành công, hãy đăng nhập.")
                return redirect(url_for("login"))
            except pymysql.MySQLError as e:
                flash("Lỗi: " + str(e.args[-1]))
    return render_template("register.html")


# ---------- NHÀ TRỌ, SỬA PHÒNG ----------
@app.route("/nha-tro", methods=["GET", "POST"])
@login_required("CHU_TRO")
def nha_tro():
    uid = session["uid"]
    if request.method == "POST":
        run("INSERT INTO nha_tro (ma_chu_tro, ten_nha_tro, dia_chi) VALUES (%s,%s,%s)", (uid, request.form["ten"], request.form["dc"]), "Đã thêm nhà trọ.")
        return redirect(url_for("nha_tro"))
    rows = [dict(r, trang_thai="OK") for r in q("SELECT * FROM nha_tro WHERE ma_chu_tro=%s", (uid,))]
    return render_template("page.html", title="Nhà trọ", form=[("ten", "Tên nhà trọ", "text", None), ("dc", "Địa chỉ", "text", None)],
                           cols=[("ten_nha_tro", "Tên", ""), ("dia_chi", "Địa chỉ", "")], rows=rows, act=("xoa_nha_tro", "ma_nha_tro", "Xóa", "OK"))


@app.post("/nha-tro/<int:id>/xoa")
@login_required("CHU_TRO")
def xoa_nha_tro(id):
    run("DELETE FROM nha_tro WHERE ma_nha_tro=%s AND ma_chu_tro=%s", (id, session["uid"]), "Đã xóa nhà trọ (nếu chưa có phòng).")
    return redirect(url_for("nha_tro"))


@app.route("/phong/<int:id>/sua", methods=["GET", "POST"])
@login_required("CHU_TRO")
def sua_phong(id):
    p = q("SELECT p.* FROM phong p JOIN nha_tro n ON n.ma_nha_tro=p.ma_nha_tro WHERE p.ma_phong=%s AND n.ma_chu_tro=%s", (id, session["uid"]), True)
    if not p:
        abort(404)
    if request.method == "POST":
        f = request.form
        run("UPDATE phong SET so_phong=%s, dien_tich=%s, gia_thue=%s, trang_thai=IF(trang_thai='DANG_THUE','DANG_THUE',%s) WHERE ma_phong=%s",
            (f["so_phong"], f["dien_tich"] or None, f["gia_thue"], f["trang_thai"], id), "Đã cập nhật phòng.")
        return redirect(url_for("phong"))
    form = [("so_phong", "Số phòng", "text", p["so_phong"]), ("dien_tich", "Diện tích", "number", p["dien_tich"] or ""),
            ("gia_thue", "Giá thuê", "number", int(p["gia_thue"])), ("trang_thai", "Trạng thái (phòng đang thuê giữ nguyên)", "select", [("TRONG", "Trống"), ("BAO_TRI", "Bảo trì")])]
    return render_template("page.html", title=f"Sửa phòng {p['so_phong']}", form=form, submit="Lưu", cols=[], rows=[])


# ---------- HÓA ĐƠN: tạo (có cảnh báo thiếu chỉ số), sửa dòng, gửi, nhắc ----------
@app.post("/hoa-don/tao")
@login_required("CHU_TRO")
def tao_hoa_don():
    t, n = int(request.form["thang"]), int(request.form["nam"])
    hds = q("SELECT h.*, p.so_phong, p.ma_nha_tro FROM hop_dong h JOIN phong p ON p.ma_phong=h.ma_phong "
            "JOIN nha_tro nt ON nt.ma_nha_tro=p.ma_nha_tro WHERE nt.ma_chu_tro=%s AND h.trang_thai='HIEU_LUC' "
            "AND h.ngay_bat_dau <= %s", (session["uid"], date(n, t, 28)))
    tao, co, thieu = 0, 0, []
    for h in hds:
        if q("SELECT 1 AS x FROM hoa_don WHERE ma_hop_dong=%s AND thang=%s AND nam=%s", (h["ma_hop_dong"], t, n), True):
            co += 1
            continue
        lines, miss = [(None, f"Tiền phòng {h['so_phong']} tháng {t}/{n}", 1, h["gia_thue"])], False
        for d in q("SELECT * FROM dich_vu WHERE ma_nha_tro=%s", (h["ma_nha_tro"],)):
            if d["cach_tinh"] == "CO_DINH":
                lines.append((d["ma_dich_vu"], d["ten_dich_vu"], 1, d["don_gia"]))
                continue
            c = q("SELECT * FROM chi_so_dich_vu WHERE ma_hop_dong=%s AND ma_dich_vu=%s AND thang=%s AND nam=%s",
                  (h["ma_hop_dong"], d["ma_dich_vu"], t, n), True)
            if not c:
                miss = True
                thieu.append(f"{h['so_phong']} ({d['ten_dich_vu']})")
                continue
            lines.append((d["ma_dich_vu"], f"{d['ten_dich_vu']} ({c['chi_so_cu']} → {c['chi_so_moi']} {d['don_vi']})",
                          c["chi_so_moi"] - c["chi_so_cu"], d["don_gia"]))
        if miss:
            continue
        conn = db()
        conn.autocommit(False)
        try:
            with conn.cursor() as cur:
                cur.execute("INSERT INTO hoa_don (ma_hop_dong, thang, nam, han_thanh_toan) VALUES (%s,%s,%s,%s)",
                            (h["ma_hop_dong"], t, n, date(n, t, h["ngay_chot"]) + timedelta(days=5)))
                hid, tong = cur.lastrowid, 0
                for dv, mo_ta, sl, dg in lines:
                    tt = int(round(sl * dg))
                    tong += tt
                    cur.execute("INSERT INTO chi_tiet_hoa_don (ma_hoa_don, ma_dich_vu, mo_ta, so_luong, don_gia, thanh_tien) VALUES (%s,%s,%s,%s,%s,%s)",
                                (hid, dv, mo_ta, sl, dg, tt))
                cur.execute("UPDATE hoa_don SET tong_tien=%s WHERE ma_hoa_don=%s", (tong, hid))
            conn.commit()
            tao += 1
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.autocommit(True)
    flash(f"Đã tạo {tao} hóa đơn tháng {t}/{n}." + (f" Đã có sẵn: {co}." if co else ""))
    if thieu:
        flash("⚠️ Bỏ qua do thiếu chỉ số: " + ", ".join(thieu))
    return redirect(url_for("hoa_don"))


@app.post("/hoa-don/<int:hid>/dong")
@login_required("CHU_TRO")
def them_dong(hid):
    inv = q(INV + scope() + " AND v.ma_hoa_don=%s", (session["uid"], hid), True)
    if not inv or inv["da_thu"] > 0:
        flash("Chỉ chỉnh sửa được hóa đơn chưa có khoản thu nào.")
    else:
        sl = int(request.form["thanh_tien"])
        ex("INSERT INTO chi_tiet_hoa_don (ma_hoa_don, mo_ta, so_luong, don_gia, thanh_tien) VALUES (%s,%s,1,%s,%s)", (hid, request.form["mo_ta"], sl, sl))
        retotal(hid)
        flash("Đã thêm khoản phụ thu / giảm trừ.")
    return redirect(url_for("chi_tiet", hid=hid))


@app.post("/hoa-don/<int:hid>/dong/<int:cid>/xoa")
@login_required("CHU_TRO")
def xoa_dong(hid, cid):
    inv = q(INV + scope() + " AND v.ma_hoa_don=%s", (session["uid"], hid), True)
    if inv and inv["da_thu"] == 0:
        ex("DELETE FROM chi_tiet_hoa_don WHERE ma_chi_tiet=%s AND ma_hoa_don=%s", (cid, hid))
        retotal(hid)
    return redirect(url_for("chi_tiet", hid=hid))


def retotal(hid):
    ex("UPDATE hoa_don SET tong_tien=(SELECT COALESCE(SUM(thanh_tien),0) FROM chi_tiet_hoa_don WHERE ma_hoa_don=%s) WHERE ma_hoa_don=%s", (hid, hid))
    sync_status(hid)


@app.post("/hoa-don/<int:hid>/thong-bao/<kind>")
@login_required("CHU_TRO")
def gui_thong_bao(hid, kind):
    inv = q(INV + scope() + " AND v.ma_hoa_don=%s", (session["uid"], hid), True)
    if not inv or kind not in ("gui", "nhac"):
        abort(404)
    kh = q("SELECT ma_khach_thue FROM hop_dong WHERE ma_hop_dong=%s", (inv["ma_hop_dong"],), True)["ma_khach_thue"]
    if kind == "gui":
        notify(kh, f"Hóa đơn tháng {inv['thang']}/{inv['nam']} phòng {inv['so_phong']}: {vnd(inv['tong_tien'])}, hạn {inv['han_thanh_toan']}.", hid)
    else:
        notify(kh, f"Nhắc thanh toán hóa đơn tháng {inv['thang']}/{inv['nam']}: còn nợ {vnd(inv['con_no'])}, hạn {inv['han_thanh_toan']}.", hid)
    flash("Đã gửi thông báo cho khách thuê.")
    return redirect(url_for("chi_tiet", hid=hid))


# ---------- THANH TOÁN ONLINE: webhook HMAC + giả lập cổng ----------
def ghi_nhan_online(hid, sotien, magd):
    if q("SELECT 1 AS x FROM thanh_toan WHERE ma_giao_dich=%s AND trang_thai='THANH_CONG'", (magd,), True):
        return False, "Giao dịch trùng, bỏ qua."
    v = q("SELECT con_no FROM v_cong_no WHERE ma_hoa_don=%s", (hid,), True)
    if not v or sotien <= 0 or sotien > v["con_no"]:
        return False, "Số tiền không khớp hóa đơn."
    conn = db()
    conn.autocommit(False)
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT ma_hoa_don FROM hoa_don WHERE ma_hoa_don=%s FOR UPDATE", (hid,))
            cur.execute("INSERT INTO thanh_toan (ma_hoa_don, so_tien, phuong_thuc, ma_giao_dich, trang_thai) VALUES (%s,%s,'CHUYEN_KHOAN',%s,'THANH_CONG')",
                        (hid, sotien, magd))
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.autocommit(True)
    sync_status(hid)
    return True, "OK"


@app.post("/api/webhooks/payment")
def webhook():
    raw = request.get_data()
    if not hmac.compare_digest(request.headers.get("X-Signature", ""), hmac.new(SECRET.encode(), raw, hashlib.sha256).hexdigest()):
        return {"ok": False, "error": "Chữ ký không hợp lệ"}, 401
    d = request.get_json(force=True)
    m = re.search(r"HD(\d+)", str(d.get("noi_dung", "")).upper())
    if not m:
        return {"ok": False, "error": "Không tìm thấy mã hóa đơn trong nội dung"}, 400
    ok, msg = ghi_nhan_online(int(m.group(1)), int(d["so_tien"]), str(d["ma_giao_dich"]))
    return {"ok": ok, "message": msg}, (200 if ok else 409)


@app.post("/hoa-don/<int:hid>/gia-lap")
@login_required("KHACH_THUE")
def gia_lap(hid):
    inv = q(INV + scope() + " AND v.ma_hoa_don=%s", (session["uid"], hid), True)
    if not DEMO or not inv:
        abort(404)
    ok, msg = ghi_nhan_online(hid, int(inv["con_no"]), "SIM" + str(int(time.time() * 1000)))
    flash("Cổng thanh toán (giả lập) báo thành công." if ok else msg)
    return redirect(url_for("chi_tiet", hid=hid))


# ---------- BIÊN LAI (có QR xác thực) ----------
@app.route("/bien-lai/<int:pid>")
@login_required()
def bien_lai(pid):
    r = q(INV.replace("SELECT v.*,", "SELECT t.ma_thanh_toan, t.so_tien, t.phuong_thuc, t.ma_giao_dich, t.ngay_thanh_toan, t.trang_thai AS tt_gd, v.*,") .replace("FROM v_cong_no v", "FROM thanh_toan t JOIN v_cong_no v ON v.ma_hoa_don=t.ma_hoa_don")
          + scope() + " AND t.ma_thanh_toan=%s AND t.trang_thai='THANH_CONG'", (session["uid"], pid), True)
    if not r:
        abort(404)
    return render_template("receipt.html", r=r, link=url_for("xac_thuc", pid=pid, k=ky(pid), _external=True), bank=BANK)


@app.route("/xac-thuc/<int:pid>")
def xac_thuc(pid):
    ok = hmac.compare_digest(request.args.get("k", ""), ky(pid))
    r = q("SELECT t.so_tien, t.ngay_thanh_toan, t.ma_hoa_don FROM thanh_toan t WHERE t.ma_thanh_toan=%s AND t.trang_thai='THANH_CONG'", (pid,), True) if ok else None
    return render_template("verify.html", r=r, pid=pid)


# ---------- KHÁCH THUÊ ----------
def khach_home():
    uid, today = session["uid"], date.today()
    inv = q(INV + scope() + " AND v.con_no>0 ORDER BY v.han_thanh_toan", (uid,))
    for r in inv:
        d = (r["han_thanh_toan"] - today).days
        r["nhac"] = f"Quá hạn {-d} ngày" if d < 0 else (f"Hạn trong {d} ngày" if d <= 3 else "")
    hd = q("SELECT h.*, p.so_phong, n.ten_nha_tro FROM hop_dong h JOIN phong p ON p.ma_phong=h.ma_phong JOIN nha_tro n ON n.ma_nha_tro=p.ma_nha_tro "
           "WHERE h.ma_khach_thue=%s AND h.trang_thai='HIEU_LUC'", (uid,))
    return render_template("khach.html", inv=inv, hd=hd, tong_no=sum(r["con_no"] for r in inv))


@app.route("/hop-dong-cua-toi")
@login_required("KHACH_THUE")
def hd_cua_toi():
    rows = q("SELECT h.*, p.so_phong, n.ten_nha_tro FROM hop_dong h JOIN phong p ON p.ma_phong=h.ma_phong JOIN nha_tro n ON n.ma_nha_tro=p.ma_nha_tro "
             "WHERE h.ma_khach_thue=%s ORDER BY h.ma_hop_dong DESC", (session["uid"],))
    cols = [("ten_nha_tro", "Nhà trọ", ""), ("so_phong", "Phòng", ""), ("ngay_bat_dau", "Từ", ""), ("ngay_ket_thuc", "Đến", ""),
            ("gia_thue", "Giá thuê", "m"), ("tien_coc", "Tiền cọc", "m"), ("ngay_chot", "Ngày chốt", ""), ("trang_thai", "Trạng thái", "")]
    return render_template("page.html", title="📄 Hợp đồng của tôi", cols=cols, rows=rows)


@app.route("/chi-so-cua-toi")
@login_required("KHACH_THUE")
def chi_so_cua_toi():
    rows = q("SELECT c.*, d.ten_dich_vu, d.don_vi, (c.chi_so_moi-c.chi_so_cu) AS tieu_thu FROM chi_so_dich_vu c JOIN dich_vu d ON d.ma_dich_vu=c.ma_dich_vu "
             "JOIN hop_dong h ON h.ma_hop_dong=c.ma_hop_dong WHERE h.ma_khach_thue=%s ORDER BY c.nam DESC, c.thang DESC", (session["uid"],))
    cols = [("thang", "Tháng", ""), ("nam", "Năm", ""), ("ten_dich_vu", "Dịch vụ", ""), ("chi_so_cu", "Chỉ số cũ", ""),
            ("chi_so_moi", "Chỉ số mới", ""), ("tieu_thu", "Tiêu thụ", ""), ("don_vi", "Đơn vị", "")]
    return render_template("page.html", title="🔢 Chỉ số điện, nước của tôi", cols=cols, rows=rows)


@app.route("/lich-su")
@login_required()
def lich_su():
    rows = q("SELECT t.*, v.thang, v.nam, p.so_phong FROM thanh_toan t JOIN v_cong_no v ON v.ma_hoa_don=t.ma_hoa_don JOIN hop_dong h ON h.ma_hop_dong=v.ma_hop_dong "
             "JOIN phong p ON p.ma_phong=h.ma_phong JOIN nha_tro n ON n.ma_nha_tro=p.ma_nha_tro " + scope() + " ORDER BY t.ngay_thanh_toan DESC", (session["uid"],))
    cols = [("ngay_thanh_toan", "Ngày", ""), ("so_phong", "Phòng", ""), ("thang", "Tháng HĐ", ""), ("so_tien", "Số tiền", "m"),
            ("phuong_thuc", "Phương thức", ""), ("ma_giao_dich", "Mã giao dịch", ""), ("trang_thai", "Trạng thái", "")]
    return render_template("page.html", title="🧾 Lịch sử thanh toán & biên lai", cols=cols, rows=rows, link=("bien_lai", "ma_thanh_toan", "Biên lai", "pid"), link_when="THANH_CONG")


@app.route("/thong-bao")
@login_required()
def thong_bao():
    rows = q("SELECT * FROM thong_bao WHERE ma_nguoi_nhan=%s ORDER BY ngay_tao DESC LIMIT 100", (session["uid"],))
    ex("UPDATE thong_bao SET da_doc=1 WHERE ma_nguoi_nhan=%s", (session["uid"],))
    return render_template("page.html", title="🔔 Thông báo", cols=[("ngay_tao", "Thời gian", ""), ("noi_dung", "Nội dung", "")], rows=rows,
                           link=("chi_tiet", "ma_hoa_don", "Xem hóa đơn", "hid"))


# ---------- BÁO CÁO: lọc năm, Excel (CSV), in PDF ----------
def bc_rows(nam):
    return q("SELECT v.nam, v.thang, COUNT(*) so_hd, SUM(v.tong_tien) tong_tien, SUM(v.da_thu) da_thu, SUM(v.con_no) con_no FROM v_cong_no v "
             "JOIN hop_dong h ON h.ma_hop_dong=v.ma_hop_dong JOIN phong p ON p.ma_phong=h.ma_phong JOIN nha_tro n ON n.ma_nha_tro=p.ma_nha_tro "
             "WHERE n.ma_chu_tro=%s AND v.nam=%s GROUP BY v.nam, v.thang ORDER BY v.thang", (session["uid"], nam))


@app.route("/bao-cao")
@login_required("CHU_TRO")
def bao_cao():
    nam = int(request.args.get("nam", date.today().year))
    rows = bc_rows(nam)
    return render_template("bao_cao.html", rows=rows, nam=nam, mx=max([r["tong_tien"] for r in rows] + [1]))


@app.route("/bao-cao.csv")
@login_required("CHU_TRO")
def bao_cao_csv():
    nam = int(request.args.get("nam", date.today().year))
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["Tháng", "Năm", "Số hóa đơn", "Phải thu", "Đã thu", "Còn nợ"])
    for r in bc_rows(nam):
        w.writerow([r["thang"], r["nam"], r["so_hd"], int(r["tong_tien"]), int(r["da_thu"]), int(r["con_no"])])
    return Response("\ufeff" + out.getvalue(), mimetype="text/csv", headers={"Content-Disposition": f"attachment; filename=bao_cao_{nam}.csv"})



if __name__ == "__main__":
    app.run(debug=True)
